﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Networking.BackgroundTransfer;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace testing
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            Loaded += MainPage_Loaded;
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            //FileOpenPicker picker = new FileOpenPicker();
            //picker.SuggestedStartLocation = PickerLocationId.VideosLibrary;
            //picker.ViewMode = PickerViewMode.Thumbnail;
            //picker.FileTypeFilter.Add(".mp4");
            //picker.FileTypeFilter.Add(".avi");
            //StorageFile videoFile = await picker.PickSingleFileAsync();
            //if (videoFile != null)
            //{
            //    var stream = await videoFile.OpenAsync(FileAccessMode.Read);
            //    videoPlayer.SetSource(stream, videoFile.FileType);
            //    videoPlayer.Play();
            //}

            
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            FileSavePicker picker = new FileSavePicker();
            picker.FileTypeChoices.Add("All Files", new List<String>() { downloadLink.Text.Substring(downloadLink.Text.LastIndexOf(".")) });
            StorageFile file = await picker.PickSaveFileAsync();
            BackgroundDownloader downloader = new BackgroundDownloader();
            DownloadOperation downloadOperation = downloader.CreateDownload(new Uri(downloadLink.Text), file);
            var progress = new Progress<DownloadOperation>(ProgressFunction);
            await downloadOperation.StartAsync().AsTask(progress);
            await new MessageDialog("Download Completed").ShowAsync();
        }

        private void ProgressFunction(DownloadOperation obj)
        {
            double progress = (obj.Progress.BytesReceived / obj.Progress.TotalBytesToReceive);
            bar.Value = progress * 100;
            if (progress >= 1.0)
            { 

            }

        }
    }
}
