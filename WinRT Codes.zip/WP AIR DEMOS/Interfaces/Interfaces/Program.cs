﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            Logger log = new Logger(new DatabaseLog());
            Console.ReadLine();
        }
    }

    interface ILog
    {
        void Log( string text );
    }

    class FileLog : ILog
    {
        public void Log(string text)
        {
            Console.WriteLine("File Log: " + Environment.NewLine + text);
        }
    }

    class DatabaseLog : ILog
    {
        public void Log(string text)
        {
            Console.WriteLine("Database Log: " + Environment.NewLine + text);
        }
    }

    class Logger
    {
        private ILog logger;
        private ILog logger2;
        public Logger(ILog log)
        {
            logger = log;
            logger.Log("this is the text string for logging");
        }

        public Logger(ILog log, ILog log2)
        {
            logger = log;
            logger2 = log2;
            logger.Log("this is the text string for logging");
            logger2.Log("this is the text string for logging");
        }
    }
}
