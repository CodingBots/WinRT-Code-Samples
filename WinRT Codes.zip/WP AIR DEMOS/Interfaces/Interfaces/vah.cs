﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    public interface IVah
    {
        void Drive(string x);
        void Stop(string x);
    }

    class car : IVah
    {
        public void Drive(string x)
        {
            Console.WriteLine(x);
        }

        public void Stop(string x)
        {
            Console.WriteLine(x);
        }
    }

    class truck : IVah
    {
    public void Drive(string x)
    {
        Console.WriteLine(x);
    }

    public void Stop(string x)
    {
        Console.WriteLine(x);
    }
}
}
