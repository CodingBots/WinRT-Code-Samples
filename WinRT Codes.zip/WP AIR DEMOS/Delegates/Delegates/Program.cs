﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
{
    class Program
    {
        delegate int Calculator(int num);
        static int DoubleIt(int num)
        {
            return num * 2;
        }

        static int HalveIt(int num)
        {
            return num / 2;
        }

        static int TripleIt(int num)
        {
            return num * 3;
        }

        static void Main(string[] args)
        {
            int num = 6;
            Calculator cal = DoubleIt;
            cal += TripleIt;
            cal += HalveIt;

            int result = cal(num);
            Console.WriteLine(result);

            Console.ReadLine();
        }
    }
}
