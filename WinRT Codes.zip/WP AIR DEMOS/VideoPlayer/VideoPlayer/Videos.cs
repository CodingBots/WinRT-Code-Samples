﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;

namespace VideoPlayer
{
    public class Videos
    {
        public string MovieName { get; set; }
        public string Cat { get; set; }
        public StorageFile VideoFile { get; set; }
    }
}
