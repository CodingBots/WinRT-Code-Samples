﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, person> d = new Dictionary<int, person>();

            for (int i = 0; i < 10; i++)
            {
                person p = new person();
                p.Name = "name" + i;
            }
        }
    }
}
