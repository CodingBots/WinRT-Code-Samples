﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Devices.Geolocation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace GoogleLocationApiDemo
{
	/// <summary>
	/// An empty page that can be used on its own or navigated to within a Frame.
	/// </summary>
	public sealed partial class MainPage : Page
	{
		public MainPage()
		{
			this.InitializeComponent();
		}

		string lat;
		string lng;
		private async void Button_Click(object sender, RoutedEventArgs e)
		{
			Geolocator locator = new Geolocator();
			locator.DesiredAccuracy = PositionAccuracy.High;
			Geoposition position = await locator.GetGeopositionAsync();
			lat = position.Coordinate.Latitude.ToString();
			lng = position.Coordinate.Longitude.ToString();
			txtlat.Text = lat;
			txtlng.Text = lng;
		}

		private async void Button_Click_1(object sender, RoutedEventArgs e)
		{
			string API_KEY = "AIzaSyBhTU866aib8KA1Z4BZaRLgm2UIu0MOOHk";
			string query = txtQuery.Text;
			string radius = txtRadius.Text;

            //string link = "https://maps.googleapis.com/maps/api/streetview?size=600x300&location=" + lat + "," + lng + "&heading=151.78&pitch=-0.76&key="+API_KEY;

			string link = "https://maps.googleapis.com/maps/api/place/radarsearch/json?location="+ lat +","+ lng +"&radius="+ radius +"&types="+ query +"&key="+ API_KEY;

			try
			{
				bar.Visibility = Windows.UI.Xaml.Visibility.Visible;
				btnLoc.IsEnabled = false;
				btnPlc.IsEnabled = false;
				using (HttpClient client = new HttpClient())
				{
					string json = await client.GetStringAsync(new Uri(link));
                    Loc loc = JsonConvert.DeserializeObject<Loc>(json);
                    List<Result> list = new List<Result>();
                    foreach (var item in loc.results)
                    {
                        list.Add(item);
                    }
                    myListView.DataContext = list;
				}
			}
			catch (Exception ex)
			{
				txtError.Text = "Error connecting to internet...";
			}
			finally
			{
				bar.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
				btnLoc.IsEnabled = true;
				btnPlc.IsEnabled = true;
			}
		}

        private void myListView_Tapped(object sender, TappedRoutedEventArgs e)
        {
            Frame.Navigate(typeof(Page2), myListView.SelectedItem);
        }
	}
}
