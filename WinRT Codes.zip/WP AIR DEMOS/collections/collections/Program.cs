﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace collections
{
    class Program
    {
        static void Main(string[] args)
        {
            // generic list that contains all type of objects (boxing and unboxing concepts)
            ArrayList arraylist = new ArrayList();
            arraylist.Add(1);
            arraylist.Add("ninja");
            arraylist.Add(3.56);
            arraylist.Add(45);

            foreach (var item in arraylist)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine();

            // List in which we can also declear the type of elements
            List<string> list = new List<string>();
            list.Add("hi");
            list.Add("guys");
            list.Add("we are");
            list.Add("using");
            list.Add("list");
            list.Add("of strings");

            foreach (string item in list)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine();

            // Dictonaries: Key value pair
            Dictionary<int, string> dictonary = new Dictionary<int, string>();
            dictonary.Add(110234, "Student 1");
            dictonary.Add(110607, "Student 2");
            dictonary.Add(110617, "Student 3");
            dictonary.Add(110623, "Student 4");

            foreach (var item in dictonary)
            {
                Console.WriteLine("Key: " + item.Key + " Value: " + item.Value);
            }


            Console.ReadLine();

        }
    }
}
