﻿using NotificationsExtensions.ToastContent;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel.Background;
using Windows.UI.Notifications;

namespace MyBackgroundTask
{
    public sealed class MyBgClass : IBackgroundTask
    {
        public void Run(IBackgroundTaskInstance taskInstance)
        {
            var deferrel = taskInstance.GetDeferral();

            GenerateToastNotification();

            deferrel.Complete();
        }

        private void GenerateToastNotification()
        {
            var toastContent = ToastContentFactory.CreateToastText02();
            toastContent.TextHeading.Text = "My Background Task";
            toastContent.TextBodyWrap.Text = "Message from background task";
            var toast = toastContent.CreateNotification();
            ToastNotificationManager.CreateToastNotifier().Show(toast);
        }
    }
}
