﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace propertuies
{
    class Program
    {
        delegate void GuestHandler( string name);
        event GuestHandler EnterEvent;
        public string Name { get; set; }        
        static void Main(string[] args)
        {
            //ArrayList x = new ArrayList();
            List<int> x = new List<int>();
            x.Add(5);
            x.Add(6);

            foreach (int item in x)
            {
                Console.WriteLine(item.ToString());
                
            }



            //Program prog = new Program();
            //prog.Name = "XYZ";
            //prog.EnterEvent += NOtifyA;
            //prog.EnterEvent += NOtifyB;
            //prog.Enter();
            Console.ReadLine();
        }


        static void NOtifyA(string name)
        { 
            Console.WriteLine("A:  Guest " + name + " entered");
        }

        static void NOtifyB(string name)
        {
            Console.WriteLine("B:  Guest " + name + " entered");
        }

        public void Enter()
        {
            if (EnterEvent != null)
            {
                EnterEvent(Name);
            }

        }
    }

}
