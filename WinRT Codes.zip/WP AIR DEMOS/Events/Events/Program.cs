﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Events
{
    class Guest
    {
        delegate void GuestHandler( string guestName );
        event GuestHandler EnterEvent;
        //public string Name { get; set; }

        public void Enter()
        {
            if (EnterEvent != null)
            {
                EnterEvent(" XYZ ");
            }
        }
        
        static void Main(string[] args)
        {
            Guest guest = new Guest();
            guest.Name = "Danyal Malik";
            
            guest.EnterEvent += NitifyManager;
            guest.EnterEvent += NotifyHost;

            guest.Enter();
            Console.ReadLine();

        }

        private static void NotifyHost(string guestName)
        {
            Console.WriteLine("Host: Guest Named " + guestName + " has Entered");
        }

        private static void NitifyManager(string guestName)
        {
            Console.WriteLine("Manager: Guest Named " + guestName + " has Entered");            
        }
    }
}
