﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Movies_DB
{
    public class Movie
    {
        public string MovieName { get; set; }
        public string MovieType { get; set; }
        public string MovieDuration { get; set; }
    }
}
