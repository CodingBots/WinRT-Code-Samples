﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace JsonDemo
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            List<Student> stds = new List<Student>();

            for (int i = 0; i < 10; i++)
            {
                Student s = new Student();
                s.Age = i+20;
                s.Name = "Student " + i.ToString();
                stds.Add(s);
            }

            string json = JsonConvert.SerializeObject(stds,Formatting.Indented);
            StorageFile myJsonFile = await ApplicationData.Current.LocalFolder.CreateFileAsync("StudentsJson.txt", CreationCollisionOption.ReplaceExisting);

            await FileIO.WriteTextAsync(myJsonFile, json);
        }


        private async void Button_Click_2(object sender, RoutedEventArgs e)
        {
            StorageFile file = await ApplicationData.Current.LocalFolder.GetFileAsync("StudentsJson.txt");
            string json = await FileIO.ReadTextAsync(file);
            List<Student> std = JsonConvert.DeserializeObject<List<Student>>(json);
            this.DataContext = std;
        }

    }
}
