﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace properties
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        person p = new person();
        public MainPage()
        {
            Loaded += MainPage_Loaded;
            this.InitializeComponent();
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            p.Name = "Danyal Malik";

            //txtBlockmyName.DataContext = p;
            //txtBoxBoxName.DataContext = p;

            ObservableCollection<person> persons = new ObservableCollection<person>();
            for (int i = 0; i < 10; i++)
            {
                p = new person();
                p.Name = "Name " + i.ToString();
                p.Age = i+30;
                persons.Add(p);
            }

            this.DataContext = persons;
            //myListView.DataContext = persons;
            //myListView2.DataContext = persons;
        }

        private void myListView2_Tapped(object sender, TappedRoutedEventArgs e)
        {
            //if (myListView2.SelectedIndex != -1)
            //{
            //    person p = myListView2.SelectedItem as person;
            //    dynamic parameter = new ExpandoObject();
            //    parameter.Name = p.Name;
            //    parameter.Age = p.Age.ToString();
            //    this.Frame.Navigate(typeof(PersonDetails), parameter);
            //}
        }

        //private async void ButtonChangeText_Click(object sender, RoutedEventArgs e)
        //{
        //    Button btn = new Button();
        //    await new MessageDialog(btn.GetType().FullName).ShowAsync();
        //}

        //private async void ButtonChangeText_Click(object sender, RoutedEventArgs e)   
        //{
        //    //Button b = new Button();
        //    string b = "asdsdfasdf";
        //    object obj = b as object;

        //    if (obj is Button)
        //    {
        //        await new MessageDialog("This is Button Object").ShowAsync();
        //    }
        //    else if (obj is string)
        //    {
        //        await new MessageDialog("This is string Object").ShowAsync();
        //    }
        //    else if (obj is StackPanel)
        //    {
        //        await new MessageDialog("This is StackPanel Object").ShowAsync();
        //    }
        //}
    } 
}