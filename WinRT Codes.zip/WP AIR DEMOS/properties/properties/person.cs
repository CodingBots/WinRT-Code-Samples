﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace properties
{
    public class person : INotifyPropertyChanged
    {
        private string name;

        public string Name
        {
            get 
            {
                return name;
            }
            set 
            {
                name = value;
                OnPropertyChanges();
            }
        }

        private int age;

        public int Age
        {
            get
            {
                return age;
            }
            set
            {
                age = value;
                OnPropertyChanges();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanges( [CallerMemberName] string name = "" )
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }
    }
}